# Nuvio Türkçe Kaynaklar – Stremio

Bu proje, yüklediğiniz Nuvio eklenti deposundaki HDFilmCehennemi, FilmMakinesi, FilmEkseni, DiziBal ve DiziYou sağlayıcılarını Stremio addon HTTP API biçiminde sunmak için hazırlanmış bir uyarlama iskeletidir.

## Çalıştırma

Node.js 18+ gerekir. Bağımlılık kurulumu gerekmez.

```bash
npm start
```

Ardından Stremio'ya şu adresi ekleyin:

`http://SUNUCU_ADRESI:7000/manifest.json`

Stremio eklentisinin başka cihazlarda kullanılabilmesi için bu sunucunun internete açık HTTPS adresinde barındırılması gerekir.

## Önemli uyumluluk notu

Kaynak sağlayıcıların Nuvio veri modelleri ile Stremio meta/stream modelleri birebir aynı değildir. Bu ilk adaptör, alan eşlemesi yapar; kaynak sitelerin erişilebilirliği, anti-bot korumaları, bölüm kimliklerinin eşleşmesi ve her sağlayıcının gerçek yanıt şeması nedeniyle canlı test ve sağlayıcı bazında düzeltme gerekebilir. Stremio doğrudan statik manifest URL'siyle kaynak sağlayıcı JavaScript dosyalarını çalıştırmaz; bu Node sunucusu çalışır durumda olmalıdır.
