const http = require('http');
const fs = require('fs');
const path = require('path');
const manifest = require('./manifest.json');
const providerIds = ['hdfilmcehennemi','filmmakinesi','filmekseni','dizibal','diziyou'];
const providers = Object.fromEntries(providerIds.map(id => [id, require('./providers/'+id+'.js')]));
const scraperManifest = JSON.parse(fs.readFileSync(path.join(__dirname,'nuvio-manifest-source.json'),'utf8'));
const configs = Object.fromEntries(scraperManifest.scrapers.filter(x=>providerIds.includes(x.id)).map(x=>[x.id,x]));
const send=(res,obj)=>{res.writeHead(200,{'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Cache-Control':'no-store'});res.end(JSON.stringify(obj));};
const text=(v)=>String(v??'');
function toMeta(item,pid){
 const rawId=item.id||item.url||item.link; if(!rawId)return null;
 const title=item.name||item.title||item.label||'İsimsiz';
 const poster=item.poster||item.posterUrl||item.image||item.thumbnail;
 const year=Number(item.year)||undefined;
 const type=(item.type==='tv'||item.type==='series'||item.type==='show')?'series':'movie';
 return {id:'nuvio:'+pid+':'+Buffer.from(String(rawId)).toString('base64url'),type,name:title,...(poster?{poster}:{}),...(year?{year}:{}),...(item.description?{description:item.description}:{})};
}
function decodeId(id){const m=/^nuvio:([^:]+):(.+)$/.exec(id);if(!m)return null;try{return {pid:m[1],sourceId:Buffer.from(m[2],'base64url').toString()};}catch{return null;}}
async function catalog(pid,catalogId,type,extra={}){
 const p=providers[pid]; if(!p)return [];
 if(extra.search){const r=await p.search({query:extra.search});return (r.items||[]).map(x=>toMeta(x,pid)).filter(Boolean);}
 const original=catalogId.slice(pid.length+1);
 const page=Number(extra.skip||0); const r=await p.getCatalog({catalogId:original,type:type==='series'?'series':'movie',pageToken:String(Math.floor(page/20)+1)});
 return (r.items||[]).map(x=>toMeta(x,pid)).filter(Boolean);
}
async function handle(req,res){
 const u=new URL(req.url,'http://localhost');
 if(u.pathname==='/manifest.json')return send(res,manifest);
 const cm=/^\/catalog\/(movie|series)\/([^/]+)\.json$/.exec(u.pathname);
 if(cm){const id=cm[2];if(id==='nuvio-search'){const q=u.searchParams.get('search')||'';let all=[];for(const pid of providerIds){try{all.push(...await catalog(pid,'',cm[1],{search:q}));}catch(e){console.error(pid,e.message);}}return send(res,{metas:all});}
 const dot=id.indexOf('.');const pid=id.slice(0,dot);if(!providers[pid])return send(res,{metas:[]});try{return send(res,{metas:await catalog(pid,id,cm[1],Object.fromEntries(u.searchParams))});}catch(e){console.error(e);return send(res,{metas:[]});}}
 const sm=/^\/stream\/(movie|series)\/(.+)\.json$/.exec(u.pathname);
 if(sm){const decoded=decodeId(decodeURIComponent(sm[2]));if(!decoded||!providers[decoded.pid])return send(res,{streams:[]});try{const p=providers[decoded.pid];const streams=await p.getStreams(decoded.sourceId,sm[1]==='series'?'tv':'movie',Number(u.searchParams.get('season')||1),Number(u.searchParams.get('episode')||1));return send(res,{streams:(streams||[]).map(s=>({url:s.url,title:[s.name,s.audio,s.quality].filter(Boolean).join(' • ')||decoded.pid,...(s.headers?{behaviorHints:{proxyHeaders:{request:s.headers}}}:{}),...(s.subtitles?{subtitles:s.subtitles.map(x=>({url:x.url,lang:x.lang||'Turkish'}))}:{})}))});}catch(e){console.error(e);return send(res,{streams:[]});}}
 res.writeHead(404);res.end('Not found');
}
http.createServer((req,res)=>handle(req,res).catch(e=>{console.error(e);send(res,{error:'Internal error'});})).listen(process.env.PORT||7000,'0.0.0.0',()=>console.log('Nuvio Stremio addon listening on '+(process.env.PORT||7000)));
