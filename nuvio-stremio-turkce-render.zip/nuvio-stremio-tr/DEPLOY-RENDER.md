# Render yayını – Nuvio Türkçe Stremio

## En kolay yayınlama
1. ZIP'i bilgisayarında aç.
2. İçindeki dosyaları yeni bir GitHub deposuna yükle (depo adı: `nuvio-stremio-turkce`).
3. Render hesabında **New +** → **Blueprint** seç.
4. GitHub deponu bağla ve `render.yaml` dosyasını seç.
5. Deploy tamamlanınca Render şu biçimde bir adres verir:
   `https://nuvio-stremio-turkce.onrender.com`
6. Stremio'ya eklenecek manifest adresi:
   `https://nuvio-stremio-turkce.onrender.com/manifest.json`

## Kontrol
Tarayıcıda `/manifest.json` adresini aç. JSON manifest görünüyorsa servis ayakta demektir.

Not: Bu yapılandırma uygulamayı Render'da başlatır. Ücretsiz servis boşta kaldığında uykuya geçebilir. Kaynak sitelerin erişimi, katalog yanıtları ve yayın akışları ayrıca canlı test edilmelidir; deploy başarılı olması tüm kaynakların çalıştığını garanti etmez.
